//prot�tipos das fun��es bin�rias.
unsigned short LigarBit(unsigned short,unsigned short);
unsigned short DesligarBit(unsigned short,unsigned short);
bool TestarBit(unsigned short,unsigned short);
unsigned short andbinario(unsigned short,unsigned short);
unsigned short orbinario(unsigned short,unsigned short);
unsigned short BitsBaixos(unsigned short);
unsigned short Bitsaltos(unsigned short);

