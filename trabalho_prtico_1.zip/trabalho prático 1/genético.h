//prot�tipo das fun��es gen�ticas.
bool FuncaoAvaliacao(unsigned short);
unsigned short CruzamentoPontoUnico(unsigned short,unsigned short);
unsigned short CruzamentoAritimetico(unsigned short, unsigned short);
unsigned short MutacaoSimples(unsigned short);
unsigned short MutacaoDupla(unsigned short);

